package cis350.group.trocker;

import cis350.group.trocker.model.Member;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class MemberEditDialogController {

	    @FXML
	    private TextField firstNameField;
	    @FXML
	    private TextField lastNameField;
	    @FXML
	    private TextField gNumberField;
	    @FXML
	    private TextField phoneNumberField;
	    @FXML
	    private TextField waiverField;
	    @FXML
	    private TextField experienceField;
	    
	    @FXML
	    private Button okayBtn;
	    
	    @FXML
	    private Button cancelBtn;
	    
	    private Stage dialogStage;
	    private Member member;
	    private boolean okClicked = false;
	    
	public MemberEditDialogController() {
		// TODO Auto-generated constructor stub
	}
	
	private void initialize() {
    }
	
	 public void setDialogStage(Stage dialogStage) {
	        this.dialogStage = dialogStage;
	    }
	 
	 public void setMember(Member member) {
	        this.member = member;

	        firstNameField.setText(member.getFirstName());
	        lastNameField.setText(member.getLastName());
	        gNumberField.setText(member.getgNumber());
	        phoneNumberField.setText(member.getPhoneNumber());
	        waiverField.setText(member.isWaiver());
	        experienceField.setText(member.getExperience());
	       }
	 
	 
	 public boolean isOkClicked() {
	        return okClicked;
	    }
	 @FXML
	 private void handleOk() {
	        member.setFirstName(firstNameField.getText());
	        member.setLastName(lastNameField.getText());
	        member.setPhoneNumber(phoneNumberField.getText());
	        member.setgNumber(gNumberField.getText());
	        member.setWaiver(waiverField.getText());
	        member.setExperience(experienceField.getText());
	        
	        okClicked = true;
            dialogStage.close();
	    }
	 @FXML
	 private void handleCancel() {
	        dialogStage.close();
	    }
	 
	 @FXML
	 private void handleNewMember() {
	     Member tempMember = new Member();
	     boolean okClicked = MainApp.showMemberEditDialog(tempMember);
	     if (okClicked) {
	         MainApp.getMemberList().add(tempMember);
	     }
	 }


}
